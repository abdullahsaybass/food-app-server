export const toProductDTO = (product) => {
  if (!product) return null;

  const p = product.toObject ? product.toObject() : product;

  return {
    id: p._id,

    // ───────── Basic Info ─────────
    name: p.name,
    slug: p.slug,
    description: p.description,
    category: p.category,
    tags: p.tags ?? [],

    // ───────── Variants ─────────
    variants:
      p.variants?.map((variant) => ({
        unit: variant.unit,
        price: variant.price,
        quantity: variant.quantity,
        sku: variant.sku,
        minOrderQuantity: variant.minOrderQuantity,
        bulkPrice: variant.bulkPrice,
        stockThreshold: variant.stockThreshold,

        isLowStock:
          variant.quantity <= variant.stockThreshold,
      })) ?? [],

    // ───────── Calculated Fields ─────────
    totalStock: p.totalStock ?? 0,

    lowStockVariants: p.lowStockVariants ?? [],

    inStock: p.inStock ?? false,

    // ───────── Images ─────────
    images: p.images ?? [],

    // ───────── Product Status ─────────
    featured: p.featured,
    isActive: p.isActive,
    isDeleted: p.isDeleted,

    // ───────── Discount ─────────
    discountPercentage: p.discountPercentage ?? 0,

    // ───────── SEO ─────────
    seoTitle: p.seoTitle,
    seoDescription: p.seoDescription,

    // ───────── Supplier ─────────
    supplier: p.supplier ?? null,

    // ───────── Audit ─────────
    createdBy: p.createdBy,
    updatedBy: p.updatedBy ?? null,

    createdAt: p.createdAt,
    updatedAt: p.updatedAt,
  };
};

export const toProductListDTO = (products, pagination) => ({
  products: products.map(toProductDTO),
  pagination,
});

export const toCategoryDTO = (category) => ({
  id:   category,
  name: category.charAt(0).toUpperCase() + category.slice(1),
});