// import Joi from "joi";
// import { PRODUCT_CATEGORIES, PRODUCT_UNITS } from "./product.constants.js";
// import { ValidationError } from "../../utils/apiError.js"; // adjust path

// const imageSchema = Joi.object({
//   url: Joi.string().uri().required(),
//   altText: Joi.string().allow("").optional(),
// });

// const createProductSchema = Joi.object({
//   name: Joi.string().trim().min(2).max(150).required(),
//   description: Joi.string().trim().max(1000).allow("").optional(),
//   sku: Joi.string().trim().uppercase().alphanum().min(3).max(50).required(),
//   price: Joi.number().min(0).required(),
//   quantity: Joi.number().integer().min(0).required(),
//   unit: Joi.string()
//     .valid(...Object.values(PRODUCT_UNITS))
//     .required(),
//   category: Joi.string()
//     .valid(...Object.values(PRODUCT_CATEGORIES))
//     .required(),
//   images: Joi.array().items(imageSchema).max(10).optional(),
//   stockThreshold: Joi.number().integer().min(0).default(10).optional(),
//   isActive: Joi.boolean().optional(),
// });

// const updateProductSchema = Joi.object({
//   name: Joi.string().trim().min(2).max(150).optional(),
//   description: Joi.string().trim().max(1000).allow("").optional(),
//   sku: Joi.string().trim().uppercase().alphanum().min(3).max(50).optional(),
//   price: Joi.number().min(0).optional(),
//   quantity: Joi.number().integer().min(0).optional(),
//   unit: Joi.string()
//     .valid(...Object.values(PRODUCT_UNITS))
//     .optional(),
//   category: Joi.string()
//     .valid(...Object.values(PRODUCT_CATEGORIES))
//     .optional(),
//   images: Joi.array().items(imageSchema).max(10).optional(),
//   stockThreshold: Joi.number().integer().min(0).optional(),
//   isActive: Joi.boolean().optional(),
// }).min(1);

// const listProductsSchema = Joi.object({
//   page: Joi.number().integer().min(1).default(1),
//   limit: Joi.number().integer().min(1).max(100).default(10),
//   category: Joi.string()
//     .valid(...Object.values(PRODUCT_CATEGORIES))
//     .optional(),
//   isActive: Joi.boolean().optional(),
//   lowStock: Joi.boolean().optional(),
//   search: Joi.string().trim().optional(),
//   sortBy: Joi.string()
//     .valid("name", "price", "quantity", "createdAt", "category")
//     .default("createdAt"),
//   sortOrder: Joi.string().valid("asc", "desc").default("desc"),
// });

// const validate = (schema) => (req, res, next) => {
//   const target = req.method === "GET" ? req.query : req.body;

//   const { error, value } = schema.validate(target, {
//     abortEarly: false,
//     stripUnknown: true,
//   });

//   if (error) {
//     const messages = error.details.map((d) => d.message);

//     // ✅ Use your ValidationError
//     return next(new ValidationError(messages));
//   }
//     if (req.method === "GET") {
//       Object.assign(req.query, value);
//     } else {
//       req.body = value;
//     }
//   next();
// };


// export const validateGetCategories = (req, res, next) => next();

// export const validateCreateProduct = validate(createProductSchema);
// export const validateUpdateProduct = validate(updateProductSchema);
// export const validateListProducts = validate(listProductsSchema);

import Joi from "joi";
import {
  PRODUCT_CATEGORIES,
  PRODUCT_UNITS,
} from "./product.constants.js";

import { ValidationError } from "../../utils/apiError.js";

// ─────────────────────────────────────────────
// 🔥 IMAGE SCHEMA
// ─────────────────────────────────────────────
const imageSchema = Joi.object({
  url: Joi.string().uri().required(),

  publicId: Joi.string().allow("").optional(),

  altText: Joi.string().allow("").optional(),
});

// ─────────────────────────────────────────────
// 🔥 VARIANT SCHEMA
// ─────────────────────────────────────────────
const variantSchema = Joi.object({
  unit: Joi.string()
    .valid(...Object.values(PRODUCT_UNITS))
    .required(),

  price: Joi.number().min(0).required(),

  quantity: Joi.number().integer().min(0).required(),

  sku: Joi.string()
    .trim()
    .uppercase()
    .min(3)
    .max(100)
    .optional(),

  minOrderQuantity: Joi.number()
    .integer()
    .min(1)
    .default(1),

  bulkPrice: Joi.number()
    .min(0)
    .default(0),

  stockThreshold: Joi.number()
    .integer()
    .min(0)
    .default(10),
});

// ─────────────────────────────────────────────
// 🔥 CREATE PRODUCT
// ─────────────────────────────────────────────
const createProductSchema = Joi.object({
  // ───────── Basic Info ─────────
  name: Joi.string()
    .trim()
    .min(2)
    .max(150)
    .required(),

  description: Joi.string()
    .trim()
    .max(3000)
    .allow("")
    .optional(),

  category: Joi.string()
    .valid(...Object.values(PRODUCT_CATEGORIES))
    .required(),

  tags: Joi.array()
    .items(Joi.string().trim().lowercase())
    .optional(),

  // ───────── Variants ─────────
  variants: Joi.array()
    .items(variantSchema)
    .min(1)
    .required(),

  // ───────── Images ─────────
  images: Joi.array()
    .items(imageSchema)
    .max(10)
    .optional(),

  // ───────── Product Status ─────────
  featured: Joi.boolean().optional(),

  isActive: Joi.boolean().optional(),

  // ───────── Discount ─────────
  discountPercentage: Joi.number()
    .min(0)
    .max(100)
    .default(0),

  // ───────── SEO ─────────
  seoTitle: Joi.string()
    .trim()
    .max(150)
    .allow("")
    .optional(),

  seoDescription: Joi.string()
    .trim()
    .max(300)
    .allow("")
    .optional(),

  // ───────── Supplier ─────────
  supplier: Joi.string()
    .hex()
    .length(24)
    .optional(),
});

// ─────────────────────────────────────────────
// 🔥 UPDATE PRODUCT
// ─────────────────────────────────────────────
const updateProductSchema = Joi.object({
  name: Joi.string()
    .trim()
    .min(2)
    .max(150)
    .optional(),

  description: Joi.string()
    .trim()
    .max(3000)
    .allow("")
    .optional(),

  category: Joi.string()
    .valid(...Object.values(PRODUCT_CATEGORIES))
    .optional(),

  tags: Joi.array()
    .items(Joi.string().trim().lowercase())
    .optional(),

  variants: Joi.array()
    .items(variantSchema)
    .min(1)
    .optional(),

  images: Joi.array()
    .items(imageSchema)
    .max(10)
    .optional(),

  featured: Joi.boolean().optional(),

  isActive: Joi.boolean().optional(),

  discountPercentage: Joi.number()
    .min(0)
    .max(100)
    .optional(),

  seoTitle: Joi.string()
    .trim()
    .max(150)
    .allow("")
    .optional(),

  seoDescription: Joi.string()
    .trim()
    .max(300)
    .allow("")
    .optional(),

  supplier: Joi.string()
    .hex()
    .length(24)
    .optional(),
}).min(1);

// ─────────────────────────────────────────────
// 🔥 LIST PRODUCTS
// ─────────────────────────────────────────────
const listProductsSchema = Joi.object({
  page: Joi.number()
    .integer()
    .min(1)
    .default(1),

  limit: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .default(10),

  category: Joi.string()
    .valid(...Object.values(PRODUCT_CATEGORIES))
    .optional(),

  featured: Joi.boolean().optional(),

  isActive: Joi.boolean().optional(),

  inStock: Joi.boolean().optional(),

  lowStock: Joi.boolean().optional(),

  search: Joi.string()
    .trim()
    .optional(),

  sortBy: Joi.string()
    .valid(
      "name",
      "category",
      "createdAt",
      "featured",
      "isActive"
    )
    .default("createdAt"),

  sortOrder: Joi.string()
    .valid("asc", "desc")
    .default("desc"),
});

// ─────────────────────────────────────────────
// 🔥 VALIDATION MIDDLEWARE
// ─────────────────────────────────────────────
const validate = (schema) => (req, res, next) => {
  const target =
    req.method === "GET"
      ? req.query
      : req.body;

  const { error, value } = schema.validate(
    target,
    {
      abortEarly: false,
      stripUnknown: true,
    }
  );

  if (error) {
    const messages = error.details.map(
      (d) => d.message
    );

    return next(
      new ValidationError(messages)
    );
  }

  if (req.method === "GET") {
    Object.assign(req.query, value);
  } else {
    req.body = value;
  }

  next();
};

// ─────────────────────────────────────────────
// 🔥 EXPORTS
// ─────────────────────────────────────────────
export const validateGetCategories = (
  req,
  res,
  next
) => next();

export const validateCreateProduct =
  validate(createProductSchema);

export const validateUpdateProduct =
  validate(updateProductSchema);

export const validateListProducts =
  validate(listProductsSchema);