import asyncHandler from "../../utils/asyncHandler.js";
import * as res_ from "../../utils/apiResponse.js";
import {
  ConflictError,
  UnauthorizedError,
  ForbiddenError,
  NotFoundError,
  BadRequestError,
} from "../../utils/apiError.js";
import { MESSAGES } from "./auth.constants.js";
import * as svc from "./auth.service.js";

// ─── Helper ─────────────────────────────────────────
const assertResult = (result) => {
  if (!result) return;
  if (result.conflict) throw new ConflictError(result.message);
  if (result.unauthorized) throw new UnauthorizedError(result.message);
  if (result.forbidden) throw new ForbiddenError(result.message);
  if (result.notFound) throw new NotFoundError(result.message);
  if (result.limitReached) throw new BadRequestError(result.message);
};

// ════════════════════════════════════════════════════
// AUTH
// ════════════════════════════════════════════════════

export const register = asyncHandler(async (req, res) => {
  const result = await svc.registerUser(req.validatedBody);
  assertResult(result);

  res_.created(res, {
    message: MESSAGES.REGISTER_SUCCESS,
    data: result,
  });
});

export const login = asyncHandler(async (req, res) => {
  const result = await svc.loginUser(req.validatedBody);
  assertResult(result);

  res_.success(res, {
    message: MESSAGES.LOGIN_SUCCESS,
    data: result,
  });
});

export const logout = asyncHandler(async (req, res) => {
  await svc.logoutUser(req.user._id);
  res_.success(res, { message: MESSAGES.LOGOUT_SUCCESS });
});

// ════════════════════════════════════════════════════
// PROFILE
// ════════════════════════════════════════════════════

export const getMe = asyncHandler(async (req, res) => {
  const result = await svc.getProfile(req.user._id);
  res_.success(res, {
    message: MESSAGES.PROFILE_FETCHED,
    data: { user: result.user },
  });
});

export const updateMe = asyncHandler(async (req, res) => {
  const result = await svc.updateProfile(req.user._id, req.validatedBody);
  assertResult(result);

  res_.success(res, {
    message: MESSAGES.PROFILE_UPDATED,
    data: { user: result.user },
  });
});

export const deleteMe = asyncHandler(async (req, res) => {
  await svc.deactivateAccount(req.user._id);
  res_.success(res, { message: MESSAGES.ACCOUNT_DELETED });
});

// ─── Profile Pic ────────────────────────────────────
export const updateProfilePic = asyncHandler(async (req, res) => {
  const result = await svc.updateProfilePic(req.user._id, req.validatedBody);
  assertResult(result);

  res_.success(res, {
    message: MESSAGES.PROFILE_PIC_UPDATED,
    data: { user: result.user },
  });
});

export const removeProfilePic = asyncHandler(async (req, res) => {
  const result = await svc.removeProfilePic(req.user._id);
  assertResult(result);

  res_.success(res, {
    message: MESSAGES.PROFILE_PIC_REMOVED,
    data: { user: result.user },
  });
});

// ════════════════════════════════════════════════════
// ADDRESSES
// ════════════════════════════════════════════════════

export const addAddress = asyncHandler(async (req, res) => {
  const result = await svc.addAddress(req.user._id, req.validatedBody);
  assertResult(result);

  res_.created(res, {
    message: MESSAGES.ADDRESS_ADDED,
    data: { addresses: result.addresses },
  });
});

export const updateAddress = asyncHandler(async (req, res) => {
  const result = await svc.updateAddress(
    req.user._id,
    req.params.addressId,
    req.validatedBody
  );
  assertResult(result);

  res_.success(res, {
    message: MESSAGES.ADDRESS_UPDATED,
    data: { addresses: result.addresses },
  });
});

export const deleteAddress = asyncHandler(async (req, res) => {
  const result = await svc.deleteAddress(
    req.user._id,
    req.params.addressId
  );
  assertResult(result);

  res_.success(res, {
    message: MESSAGES.ADDRESS_DELETED,
    data: { addresses: result.addresses },
  });
});



// ════════════════════════════════════════════════════
// ADMIN
// ════════════════════════════════════════════════════

export const seedAdmin = asyncHandler(async (req, res) => {
  const key = req.headers["x-seed-key"];

  if (key !== process.env.SEED_ADMIN_KEY) {
    throw new AppError("Unauthorized", 401);
  }

  const result = await svc.seedAdmin();

  res_.success(res, {
    message: "Admin created",
    data: result,
  });
});

export const getAllUsers = asyncHandler(async (req, res) => {
  const result = await svc.getAllUsers(req.query.role);

  res_.success(res, {
    message: MESSAGES.USERS_FETCHED,
    data: { users: result.users },
  });
});

export const getUserById = asyncHandler(async (req, res) => {
  const result = await svc.getUserById(req.params.id);
  assertResult(result);

  res_.success(res, {
    message: MESSAGES.USER_FETCHED,
    data: { user: result.user },
  });
});

export const adminUpdateUser = asyncHandler(async (req, res) => {
  const result = await svc.adminUpdateUser(
    req.params.id,
    req.validatedBody
  );
  assertResult(result);

  res_.success(res, {
    message: MESSAGES.USER_UPDATED,
    data: { user: result.user },
  });
});

export const adminDeleteUser = asyncHandler(async (req, res) => {
  const result = await svc.adminDeleteUser(req.params.id);
  assertResult(result);

  res_.success(res, { message: MESSAGES.USER_DELETED });
});

// ════════════════════════════════════════════════════
// REFRESH TOKEN
// ════════════════════════════════════════════════════

export const refreshTokenController = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    throw new BadRequestError("Refresh token required");
  }

  const result = await svc.refreshAccessToken(refreshToken);
  assertResult(result);

  res_.success(res, {
    message: "Token refreshed",
    data: result,
  });
});

export const forgotPassword = asyncHandler(async (req, res) => {
  const result = await svc.forgotPassword(req.validatedBody.email);

  res_.success(res, {
    message: result.message,
  });
});

export const resetPassword = asyncHandler(async (req, res) => {
  const { token, password } = req.validatedBody;

  const result = await svc.resetPassword(token, password);
  assertResult(result);

  res_.success(res, {
    message: result.message,
  });
});