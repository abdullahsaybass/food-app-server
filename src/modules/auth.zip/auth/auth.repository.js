import User from "./user.model.js";

// ─── Lookups ─────────────────────────────────────────
export const findByEmail = (email) => User.findOne({ email });

export const findByEmailWithPassword = (email) =>
  User.findByEmailWithPassword(email);

export const findById = (id) => User.findById(id);

export const findDuplicate = (email, phone) =>
  User.findOne({ $or: [{ email }, { phone }] });

export const findPhoneExcluding = (phone, excludeId) =>
  User.findOne({ phone, _id: { $ne: excludeId } });

// ─── Writes ──────────────────────────────────────────
export const createUser = (data) => User.create(data);

export const updateById = (id, data) =>
  User.findByIdAndUpdate(id, { $set: data }, { new: true, runValidators: true });

export const deactivateById = (id) =>
  User.findByIdAndUpdate(id, { isActive: false }, { new: true });

// ─── Address operations ──────────────────────────────
export const addAddress = (id, address) =>
  User.findByIdAndUpdate(
    id,
    { $push: { addresses: address } },
    { new: true, runValidators: true }
  );

export const updateAddress = (userId, addressId, data) => {
  const setPayload = {};

  Object.keys(data).forEach((key) => {
    setPayload[`addresses.$.${key}`] = data[key];
  });

  return User.findOneAndUpdate(
    { _id: userId, "addresses._id": addressId },
    { $set: setPayload },
    { new: true, runValidators: true }
  );
};

export const deleteAddress = (userId, addressId) =>
  User.findByIdAndUpdate(
    userId,
    { $pull: { addresses: { _id: addressId } } },
    { new: true }
  );

// ─── Admin operations ────────────────────────────────
export const findAllUsers = (filter = {}) =>
  User.find(filter).select("-__v");

export const findAdmins = () => User.findAdmins();

// ─── Refresh Token ──────────────────────────────────
export const saveRefreshToken = (userId, token) =>
  User.findByIdAndUpdate(userId, { refreshToken: token });

export const removeRefreshToken = (userId) =>
  User.findByIdAndUpdate(userId, { refreshToken: null });

// ─── Password Reset ────────────────────────────────

export const setResetToken = (userId, token, expiry) =>
  User.findByIdAndUpdate(userId, {
    resetPasswordToken: token,
    resetPasswordExpires: expiry,
  });

export const findByResetToken = (token) =>
  User.findOne({
    resetPasswordToken: token,
    resetPasswordExpires: { $gt: Date.now() },
  });

export const clearResetToken = (userId) =>
  User.findByIdAndUpdate(userId, {
    resetPasswordToken: null,
    resetPasswordExpires: null,
  });