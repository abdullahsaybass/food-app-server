import express from "express";

import {
  protect,
  adminOnly,
  superAdminOnly,
} from "../../middleware/auth.middleware.js ";

import {
  validateRegister,
  validateLogin,
  validateUpdateProfile,
  validateUpdateProfilePic,
  validateAddAddress,
  validateUpdateAddress,
  validateAdminUpdateUser,
  validateForgotPassword,
  validateResetPassword,
} from "./auth.validator.js";

import {
  register,
  login,
  logout,
  getMe,
  updateMe,
  deleteMe,
  updateProfilePic,
  removeProfilePic,
  addAddress,
  updateAddress,
  deleteAddress,
  seedAdmin,
  getAllUsers,
  getUserById,
  adminUpdateUser,
  adminDeleteUser,
  refreshTokenController, // ✅ FIXED
} from "./auth.controller.js";

// ─── AUTH ROUTER ─────────────────────────────────────
export const authRouter = express.Router();

// PUBLIC
authRouter.post("/register", validateRegister, register);
authRouter.post("/login", validateLogin, login);
authRouter.post("/refresh-token", refreshTokenController); // ✅ moved to public

// PROTECTED
authRouter.post("/logout", protect, logout);

// Profile
authRouter.get("/me", protect, getMe);
authRouter.put("/me", protect, validateUpdateProfile, updateMe);
authRouter.delete("/me", protect, deleteMe);

// Profile picture
authRouter.put(
  "/me/profile-pic",
  protect,
  validateUpdateProfilePic,
  updateProfilePic
);
authRouter.delete("/me/profile-pic", protect, removeProfilePic);

// Addresses
authRouter.post(
  "/me/addresses",
  protect,
  validateAddAddress,
  addAddress
);
authRouter.put(
  "/me/addresses/:addressId",
  protect,
  validateUpdateAddress,
  updateAddress
);
authRouter.delete(
  "/me/addresses/:addressId",
  protect,
  deleteAddress
);
authRouter.post("/seed-admin", seedAdmin);

router.post("/forgot-password", validateForgotPassword, ctrl.forgotPassword);
router.post("/reset-password", validateResetPassword, ctrl.resetPassword);

// ─── ADMIN ROUTER ────────────────────────────────────
export const adminRouter = express.Router();

adminRouter.get("/", protect, adminOnly, getAllUsers);
adminRouter.get("/:id", protect, adminOnly, getUserById);
adminRouter.put(
  "/:id",
  protect,
  adminOnly,
  validateAdminUpdateUser,
  adminUpdateUser
);
adminRouter.delete("/:id", protect, superAdminOnly, adminDeleteUser);