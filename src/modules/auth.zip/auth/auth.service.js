import jwt from "jsonwebtoken";
import { JWT_EXPIRES_IN, MESSAGES } from "./auth.constants.js";
import * as repo from "./auth.repository.js";

// ─── Token helper ─────────────────────────────────────────────────────────
const generateAccessToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || JWT_EXPIRES_IN,
  });

const generateRefreshToken = (id) =>
  jwt.sign({ id }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || "30d",
  });

// ─── Register ─────────────────────────────────────────────────────────────
export const registerUser = async ({ name, phone, email, password }) => {
  const existing = await repo.findDuplicate(email, phone);
  if (existing) {
    return {
      conflict: true,
      message: existing.email === email
        ? MESSAGES.EMAIL_TAKEN
        : MESSAGES.PHONE_TAKEN,
    };
  }

  const user = await repo.createUser({ name, phone, email, password });

  const accessToken = generateAccessToken(user._id);
  const refreshToken = generateRefreshToken(user._id);

  await repo.saveRefreshToken(user._id, refreshToken);

  return { user, accessToken, refreshToken };
};

// ─── Login ────────────────────────────────────────────────────────────────
export const loginUser = async ({ email, password }) => {
  const user = await repo.findByEmailWithPassword(email);
  if (!user) {
    return { unauthorized: true, message: MESSAGES.INVALID_CREDENTIALS };
  }

  if (!user.isActive) {
    return { forbidden: true, message: MESSAGES.ACCOUNT_DEACTIVATED };
  }

  const isMatch = await user.comparePassword(password);
  if (!isMatch) {
    return { unauthorized: true, message: MESSAGES.INVALID_CREDENTIALS };
  }

  const accessToken = generateAccessToken(user._id);
  const refreshToken = generateRefreshToken(user._id);

  await repo.saveRefreshToken(user._id, refreshToken);

  // ✅ REMOVE sensitive fields
  const userObj = user.toObject();
  delete userObj.password;
  delete userObj.refreshToken;

  return { user: userObj, accessToken, refreshToken };
};

// ─── Get profile ──────────────────────────────────────────────────────────
export const getProfile = async (userId) => {
  const user = await repo.findById(userId);
  return { user };
};

// ─── Update profile ───────────────────────────────────────────────────────
export const updateProfile = async (userId, data) => {
  // If phone is being changed, ensure no other user owns it
  if (data.phone) {
    const phoneOwner = await repo.findPhoneExcluding(data.phone, userId);
    if (phoneOwner) {
      return { conflict: true, message: MESSAGES.PHONE_IN_USE };
    }
  }

  const user = await repo.updateById(userId, data);
  return { user };
};

// ─── Deactivate account ───────────────────────────────────────────────────
export const deactivateAccount = async (userId) => {
  await repo.deactivateById(userId);
};

export const logoutUser = async (userId) => {
  await repo.removeRefreshToken(userId);
};

// auth.service.js

export const addAddress = async (userId, addressData) => {
  const user = await repo.findById(userId);

  if (!user) {
    throw new Error("User not found");
  }

  // make sure addresses array exists
  if (!user.addresses) {
    user.addresses = [];
  }

  user.addresses.push(addressData);

  await user.save();

  return { addresses: user.addresses };
};

export const updateAddress = async (userId, addressId, updateData) => {
  const user = await repo.findById(userId);

  if (!user) {
    throw new Error("User not found");
  }

  const address = user.addresses.id(addressId);

  if (!address) {
    throw new Error("Address not found");
  }

  // update fields dynamically
  Object.assign(address, updateData);

  await user.save();

  return { addresses: user.addresses };
};

export const deleteAddress = async (userId, addressId) => {
  const user = await repo.findById(userId);

  if (!user) {
    throw new Error("User not found");
  }
  const address = user.addresses.id(addressId);

  if (!address) {
    throw new Error("Address not found");
  }

  // remove address
  address.deleteOne(); // ✅ best for subdocuments

  await user.save();

  return { addresses: user.addresses };
};

export const getAllUsers = async (role) => {
  const filter = role ? { role } : {};

  const users = await repo.findAllUsers(filter);

  return { users };
};

export const getUserById = async (id) => {
  const user = await repo.findById(id);

  if (!user) {
    return { notFound: true, message: "User not found" };
  }

  return { user };
};

export const adminUpdateUser = async (id, data) => {
  const user = await repo.updateById(id, data);

  if (!user) {
    return { notFound: true, message: "User not found" };
  }

  return { user };
};

export const adminDeleteUser = async (id) => {
  const user = await repo.deactivateById(id);

  if (!user) {
    return { notFound: true, message: "User not found" };
  }

  return { success: true };
};

export const seedAdmin = async () => {
  const email = "admin@test.com";

  // check if already exists
  const existing = await repo.findByEmail(email);

  if (existing) {
    return { message: "Admin already exists" };
  }

  const user = await repo.createUser({
    name: "Super Admin",
    email,
    phone: "+911234567890",
    password: "Password123",
    role: "superadmin", // 🔥 important
  });

  return { user };
};

export const refreshAccessToken = async (refreshToken) => {
  try {
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);

    const user = await repo.findById(decoded.id);
    if (!user || !user.refreshToken) {
      return { unauthorized: true };
    }

    if (user.refreshToken !== refreshToken) {
      return { unauthorized: true };
    }

    // rotate tokens
    const newAccessToken = generateAccessToken(user._id);
    const newRefreshToken = generateRefreshToken(user._id);

    await repo.saveRefreshToken(user._id, newRefreshToken);

    return {
      accessToken: newAccessToken,
      refreshToken: newRefreshToken,
    };
  } catch {
    return { unauthorized: true };
  }
};

export const forgotPassword = async (email) => {
  const user = await repo.findByEmail(email);

  if (!user) {
    // don't reveal user existence (security)
    return { success: true, message: MESSAGES.PASSWORD_RESET_EMAIL_SENT };
  }

  // generate token
  const resetToken = crypto.randomBytes(32).toString("hex");

  const hashedToken = crypto
    .createHash("sha256")
    .update(resetToken)
    .digest("hex");

  const expiry = Date.now() + 15 * 60 * 1000; // 15 mins

  await repo.setResetToken(user._id, hashedToken, expiry);

  // 👉 send email (mock for now)
  const resetUrl = `${process.env.CLIENT_URL}/reset-password/${resetToken}`;

  console.log("RESET URL:", resetUrl);

  return {
    success: true,
    message: MESSAGES.PASSWORD_RESET_EMAIL_SENT,
  };
};

// ─── Reset Password ────────────────────────────────
export const resetPassword = async (token, newPassword) => {
  const hashedToken = crypto
    .createHash("sha256")
    .update(token)
    .digest("hex");

  const user = await repo.findByResetToken(hashedToken);

  if (!user) {
    return {
      unauthorized: true,
      message: MESSAGES.PASSWORD_RESET_INVALID,
    };
  }

  user.password = newPassword;
  user.resetPasswordToken = null;
  user.resetPasswordExpires = null;

  await user.save();

  return {
    success: true,
    message: MESSAGES.PASSWORD_RESET_SUCCESS,
  };
};