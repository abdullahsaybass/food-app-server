import Joi from "joi";

// ─── Reusable sub-schemas ─────────────────────────────
const phoneSchema = Joi.string()
  .pattern(/^\+?[1-9]\d{9,14}$/)
  .messages({
    "string.pattern.base":
      "Enter a valid phone number (e.g. +919876543210)",
  });

const addressBodySchema = Joi.object({
  label: Joi.string().valid("home", "work", "other").default("home"),
  street: Joi.string().trim().required().messages({
    "any.required": "Street is required",
  }),
  city: Joi.string().trim().required().messages({
    "any.required": "City is required",
  }),
  state: Joi.string().trim().required().messages({
    "any.required": "State is required",
  }),
  postalCode: Joi.string().trim().required().messages({
    "any.required": "Postal code is required",
  }),
  country: Joi.string().trim().default("India"),
  isDefault: Joi.boolean().default(false),
});

// ─── Auth schemas ─────────────────────────────────────
const registerSchema = Joi.object({
  name: Joi.string().min(2).max(50).trim().required().messages({
    "string.min": "Name must be at least 2 characters",
    "string.max": "Name cannot exceed 50 characters",
    "any.required": "Name is required",
  }),
  phone: phoneSchema.required().messages({
    "any.required": "Phone number is required",
  }),
  email: Joi.string().email().lowercase().trim().required().messages({
    "string.email": "Enter a valid email address",
    "any.required": "Email is required",
  }),
  password: Joi.string()
    .min(8)
    .max(64)
    .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .required()
    .messages({
      "string.min": "Password must be at least 8 characters",
      "string.pattern.base":
        "Password must contain at least one uppercase letter, one lowercase letter, and one number",
      "any.required": "Password is required",
    }),
});

const loginSchema = Joi.object({
  email: Joi.string().email().lowercase().trim().required().messages({
    "string.email": "Enter a valid email address",
    "any.required": "Email is required",
  }),
  password: Joi.string().required().messages({
    "any.required": "Password is required",
  }),
});

// ─── Profile schemas ──────────────────────────────────
const updateProfileSchema = Joi.object({
  name: Joi.string().min(2).max(50).trim(),
  phone: phoneSchema,
}).min(1);

const updateProfilePicSchema = Joi.object({
  url: Joi.string().uri().required().messages({
    "string.uri": "Profile picture URL must be a valid URL",
    "any.required": "URL is required",
  }),
  publicId: Joi.string().required().messages({
    "any.required": "Cloudinary publicId is required",
  }),
});

// ─── Address schemas ──────────────────────────────────
const addAddressSchema = addressBodySchema;

const updateAddressSchema = Joi.object({
  label: Joi.string().valid("home", "work", "other"),
  street: Joi.string().trim(),
  city: Joi.string().trim(),
  state: Joi.string().trim(),
  postalCode: Joi.string().trim(),
  country: Joi.string().trim(),
  isDefault: Joi.boolean(),
}).min(1);

// ─── Admin schemas ────────────────────────────────────
const adminUpdateUserSchema = Joi.object({
  name: Joi.string().min(2).max(50).trim(),
  phone: phoneSchema,
  role: Joi.string().valid("customer", "admin", "superadmin"),
  isActive: Joi.boolean(),
}).min(1);

// ─── Middleware factory ───────────────────────────────
const validate = (schema) => (req, res, next) => {
  const { error, value } = schema.validate(req.body, {
    abortEarly: false,
    stripUnknown: true, // 🔥 removes unwanted fields
  });

  if (error) {
    return res.status(400).json({
      success: false,
      errors: error.details.map((d) => d.message),
    });
  }

  req.validatedBody = value;
  next();
};

// ─── Exports ─────────────────────────────────────────
export const validateRegister = validate(registerSchema);
export const validateLogin = validate(loginSchema);
export const validateUpdateProfile = validate(updateProfileSchema);
export const validateUpdateProfilePic = validate(updateProfilePicSchema);
export const validateAddAddress = validate(addAddressSchema);
export const validateUpdateAddress = validate(updateAddressSchema);
export const validateAdminUpdateUser = validate(adminUpdateUserSchema);