import * as productService from "./product.service.js";
import { toProductDTO, toProductListDTO } from "./product.mapper.js";
import { PRODUCT_MESSAGES } from "./product.constants.js";
import asyncHandler from "../../utils/asyncHandler.js";

export const createProduct = asyncHandler(async (req, res) => {
  const product = await productService.createProduct(req.body, req.user.id);

  res.status(201).json({
    success: true,
    message: PRODUCT_MESSAGES.CREATED,
    data: toProductDTO(product),
  });
});

export const getProduct = asyncHandler(async (req, res) => {
  const product = await productService.getProductById(req.params.id);

  res.status(200).json({
    success: true,
    message: PRODUCT_MESSAGES.FETCHED,
    data: toProductDTO(product),
  });
});

export const listProducts = asyncHandler(async (req, res) => {
  const result = await productService.getAllProducts(req.query);

  res.status(200).json({
    success: true,
    message: PRODUCT_MESSAGES.FETCHED,
    data: {
      products: result.products.map(toProductDTO),
      pagination: result.pagination,
    },
  });
});
export const getLowStockProducts = asyncHandler(async (req, res) => {
  const products = await productService.getLowStockProducts();

  res.status(200).json({
    success: true,
    message: PRODUCT_MESSAGES.LIST_FETCHED,
    data: { products: products.map(toProductDTO) },
  });
});

export const updateProduct = asyncHandler(async (req, res) => {
  const product = await productService.updateProduct(
    req.params.id,
    req.body,
    req.user.id
  );

  res.status(200).json({
    success: true,
    message: PRODUCT_MESSAGES.UPDATED,
    data: toProductDTO(product),
  });
});

export const deleteProduct = asyncHandler(async (req, res) => {
  await productService.deleteProduct(req.params.id);

  res.status(200).json({
    success: true,
    message: PRODUCT_MESSAGES.DELETED,
  });
});

export const softDeleteProduct = asyncHandler(async (req, res) => {
  await productService.softDeleteProduct(req.params.id, req.user.id);

  res.status(200).json({
    success: true,
    message: PRODUCT_MESSAGES.DELETED,
  });
});