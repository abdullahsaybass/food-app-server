import Product from "./product.model.js";

export const create = (data) => Product.create(data);

export const findById = (id) => Product.findById(id);

export const findBySku = (sku) => Product.findOne({ sku: sku.toUpperCase() });

export const findAll = async ({ filter, sort, skip, limit }) => {
  const [products, total] = await Promise.all([
    Product.find(filter).sort(sort).skip(skip).limit(limit),
    Product.countDocuments(filter),
  ]);
  return { products, total };
};

export const findLowStock = () =>
  Product.find({ isActive: true }).then((products) =>
    products.filter((p) => p.quantity <= p.stockThreshold)
  );

export const updateById = (id, data) =>
  Product.findByIdAndUpdate(id, { $set: data }, { new: true, runValidators: true });

export const deleteById = (id) => Product.findByIdAndDelete(id);

export const softDeleteById = (id, updatedBy) =>
  Product.findByIdAndUpdate(id, { $set: { isActive: false, updatedBy } }, { new: true });