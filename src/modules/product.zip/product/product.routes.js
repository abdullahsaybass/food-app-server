import { Router } from "express";
import {
  protect,
  adminOnly,
} from "../../middleware/auth.middleware.js";

import {
  validateCreateProduct,
  validateUpdateProduct,
  validateListProducts,
} from "./product.validator.js";

import * as productController from "./product.controller.js";

const router = Router();

// -----------------------------------------------------------
// Authenticated users
// -----------------------------------------------------------

router.get("/", protect, validateListProducts, productController.listProducts);

router.get("/low-stock", protect, adminOnly, productController.getLowStockProducts);

router.get("/:id", protect, productController.getProduct);

// -----------------------------------------------------------
// Admin only
// -----------------------------------------------------------

router.post("/", protect, adminOnly, validateCreateProduct, productController.createProduct);

router.put("/:id", protect, adminOnly, validateUpdateProduct, productController.updateProduct);

router.patch("/:id", protect, adminOnly, validateUpdateProduct, productController.updateProduct);

router.patch("/:id/deactivate", protect, adminOnly, productController.softDeleteProduct);

router.delete("/:id", protect, adminOnly, productController.deleteProduct);

export default router;